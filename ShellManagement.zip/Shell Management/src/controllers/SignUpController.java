package controllers;

import javafx.application.Application;
import javafx.stage.Stage;

public class SignUpController extends Application {

	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

}
