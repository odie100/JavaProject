package application;

import java.sql.*;

public class ConnexionMysql {

	@SuppressWarnings("exports")
	public Connection cn = null;
	
	@SuppressWarnings("exports")
	public static Connection connexionDb() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Project","odie","");
			System.out.println("Connection Success");
			return cn;
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Connection failed");
			e.printStackTrace();
			return null;
		}
	}
}
