package models;

public class Management {
	int idCustomer;
	String customerName;
	String productsName;
	int quantity;
	Float totalPrice;
	String date;
	
	public Management() {
		
	}
	
	public Management(int idCusto,String customerName,String productsName,int quantity,float totalPrice,String date) {
		this.idCustomer = idCusto;
		this.customerName = customerName;
		this.productsName = productsName;
		this.quantity = quantity;
		this.totalPrice=totalPrice;
		this.date = date;
		
	}

	public int getIdCustomer() {
		return idCustomer;
	}

	public void setIdCustomer(int idCustomer) {
		this.idCustomer = idCustomer;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProductsName() {
		return productsName;
	}

	public void setProductsName(String productsName) {
		this.productsName = productsName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	public Float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(Float totalPrice) {
		this.totalPrice = totalPrice;
	}
	

}
