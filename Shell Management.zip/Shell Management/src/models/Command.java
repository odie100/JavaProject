package models;

public class Command {
	
	int idCustomer;
	int idProducts;
	String dateCommand;
	int quantity_commanded;
	String productName;
	float totalPrice;

	
	public Command() {
		
	}
	
	public Command(int idCusto, int idPro, String dateCom, int quantityCom, String productName,float totalPrice) {
		this.idCustomer = idCusto;
		this.idProducts = idPro;
		this.dateCommand = dateCom;
		this.quantity_commanded = quantityCom;
		this.productName = productName;
		this.totalPrice = totalPrice;
	}

	public int getIdCustomer() {
		return idCustomer;
	}

	public void setIdCustomer(int idCustomer) {
		this.idCustomer = idCustomer;
	}

	public int getIdProducts() {
		return idProducts;
	}

	public void setIdProducts(int idProducts) {
		this.idProducts = idProducts;
	}

	public String getDateCommand() {
		return dateCommand;
	}

	public void setDateCommand(String dateCommand) {
		this.dateCommand = dateCommand;
	}

	public int getQuantity_commanded() {
		return quantity_commanded;
	}

	public void setQuantity_commanded(int quantity_commanded) {
		this.quantity_commanded = quantity_commanded;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	

}
