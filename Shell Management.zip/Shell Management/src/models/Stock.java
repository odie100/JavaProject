package models;

public class Stock {

	int idProducts;
	String productsName;
	String description;
	float unitPrice;
	int quantity;
	
	
	public Stock() {
		
	}
	
	public Stock(int idProducts, String productsName, String description, float unitPrice, int quantity) {
		this.idProducts = idProducts;
		this.productsName = productsName;
		this.description = description;
		this.unitPrice = unitPrice;
		this.quantity = quantity;
	}
	
	public int getIdProducts() {
		return idProducts;
	}
	
	public void setIdProducts(int idProducts) {
		this.idProducts = idProducts;
	}
	
	public String getProductsName() {
		return productsName;
	}
	
	public void setProductsName(String productsName) {
		this.productsName = productsName;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public float getUnitPrice() {
		return unitPrice;
	}
	
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
