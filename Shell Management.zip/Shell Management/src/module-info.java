module application {
	exports application;
	exports controllers;
	exports models;

 
	requires javafx.base;
	requires javafx.fxml;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.sql;
	requires javafx.media;
	requires javafx.swing;
	requires javafx.web;
	requires com.jfoenix;
	requires controlsfx;
	
	
	opens controllers;
	opens models;
}