package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

public class LoginController {

	@FXML
	   private Button btnSignUp;
	
    @FXML
    private void perf(ActionEvent event) {
    	Alert alert = new Alert(Alert.AlertType.INFORMATION);
    	System.out.println("hello");
    	
    }

}
