package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import application.ConnexionMysql;
import javafx.application.Application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignUpController extends Application implements Initializable{

	@SuppressWarnings("exports")
	public Connection cnx;
	@SuppressWarnings("exports")
	public PreparedStatement statement;
	
	@FXML
	private TextField fullNameField;
	@FXML
	private TextField emailField;
	@FXML
	private TextField passwordField;
	
	@FXML
	void createAccount() {
		String username = fullNameField.getText();
		String email = emailField.getText();
		String password = passwordField.getText();
		
		String query = "insert into Login (username,password,email) values (?,?,?)";
		
		try {
			statement = cnx.prepareStatement(query);
			statement.setString(1, username);
			statement.setString(2, password);
			statement.setString(3, email);
			statement.executeUpdate();
			System.out.println("Account created");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	@Override
	public void start(Stage arg0) throws Exception {	
		
	}



	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		cnx = ConnexionMysql.connexionDb();
		System.out.println("Connection Success");
	}

}
