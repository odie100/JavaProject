package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import org.controlsfx.control.textfield.TextFields;

import com.jfoenix.controls.JFXComboBox;

import application.ConnexionMysql;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Command;

public class NewRecordController extends Application implements Initializable{

	@SuppressWarnings("exports")
	public Connection cnx;
	@SuppressWarnings("exports")
	public PreparedStatement statement;
	@SuppressWarnings("exports")
	public PreparedStatement tempStatement;
	@SuppressWarnings("exports")
	public ResultSet result;
	@SuppressWarnings("exports")
	public ResultSet tempResult;
	private int idCusto ;


    @FXML
    private TableView<Command> table_newRecord;

    @FXML
    private TableColumn<Command, Integer> tab_id;

    @FXML
    private TableColumn<Command, String> tab_proName;

    @FXML
    private TableColumn<Command, Integer> tab_quantity;

    @FXML
    private TableColumn<Command, Float> tab_unitPrice;

    @FXML
    private TableColumn<Command, Float> tab_total;

    @FXML
    private TableColumn<Command, String> tab_date;
    
    @FXML
    private Button print;

    @FXML
    private Label lbl_idCusto;
    
    @FXML
    private Label lbl_total;

    @FXML
    private TextField custo_name;

    @FXML
    private Button btn_add;

    @FXML
    private TextField pro_name;

    @FXML
    private TextField quantity;

    @FXML
    private Button delete;
     
   
    public ArrayList<String> suggestion = new ArrayList<String>(); 
    public ObservableList<Command> data = FXCollections.observableArrayList();

    @FXML
    void add_record() {	
    	String nameCusto = custo_name.getText();
    	String proName = pro_name.getText();
    	String current_date = "";
    	
    	
    	//Try to get the current date
    	DateFormat format = new SimpleDateFormat("dd/MM/yy HH:mm");
    	Date date = new Date();
    	current_date = format.format(date);
    	
    	int quantity_Product =  Integer.parseInt(quantity.getText());
    	float unit_Price = 0;
    	float total_price = 0;
    	int idPro = 0;
    	boolean found = false;
    	
    	int lastIdCust = 0;
    	//get the current id customer
    	int currentIdCusto = Integer.parseInt(lbl_idCusto.getText());
    	
    	int quantityTotalProduct = 0;
    	int restQuantity = 0;
    	 
    	//Query to verify if the customer is already in the database
    	String verification = "select id_cust from Customer order by id_cust desc limit 1";
    	
    	//Query to verify if the product exist
    	String verificationProductQUery = "select id_pro , pro_name from Products";
    	//Query to add the Customer to a database
    	String beforeFirst = "insert into Customer(cust_name) values(?)";
    	//Query to select the unit price by the name of the products
    	String firstQuery = "select unit_price from Products where pro_name = ? "; //proName
    	//Query to insert the values in the database
    	String secondQuery = "insert into Command values (?,?,?,?,?,?)";
    	//Query to get the total quantity of the product available
    	String getQuantity = "select quantity from Products where pro_name = ?";
    	//Query to update the quantity of the Stock
    	String update = "update Products set quantity = ? where pro_name = ? ";
    	
    	
    	
    	//get the last id of customer
    	try {
			statement = cnx.prepareStatement(verification);
			result = statement.executeQuery();
			while(result.next()) {
				lastIdCust = result.getInt("id_cust");
			}
		} catch (SQLException e3) {
			e3.printStackTrace();
		}
    	
    	//Get the quantity total of the product to sell
    	try {
			statement = cnx.prepareStatement(getQuantity);
			statement.setString(1, proName);
			result = statement.executeQuery();
			while(result.next()) {
				quantityTotalProduct = result.getInt("quantity");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	//Try to verify if the quantity of the product is enough
    	if(quantityTotalProduct>=quantity_Product) {
    		restQuantity = quantityTotalProduct - quantity_Product;
    		try {
				statement = cnx.prepareStatement(update);
				statement.setInt(1, restQuantity);
				statement.setString(2, proName);
				statement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    		
    	  	if(currentIdCusto == lastIdCust) {
        		//Don(t insert the custo into the table if already exist
        		try {
            		statement = cnx.prepareStatement(verificationProductQUery);
        			result = statement.executeQuery();
        			while(result.next()) {
        				if(proName.equals(result.getString("pro_name"))) {
        					found = true;
        					idPro = result.getInt("id_pro");
        					//get the unit price of the product selected
        			    	try {
        			    		tempStatement = cnx.prepareStatement(firstQuery);
        						tempStatement.setString(1, proName);
        						tempResult = tempStatement.executeQuery();
        			
        						if(tempResult.next()) {
        							unit_Price = tempResult.getFloat("unit_price");
        							total_price = unit_Price*quantity_Product;
        						}
        				    	
        				    	tempStatement.close();	
        					} catch (SQLException e) {
        						e.printStackTrace();
        					  }		    	
        					}
        				}
        			
        			if (found == false){
        				Alert alert = new Alert(AlertType.INFORMATION,"This products is not available !",ButtonType.OK);
        				alert.showAndWait();
        			}
        		} catch (SQLException e1) {
        			System.out.println("Products unavailable !");
        		}
            	
        		//Insert into
            	try {
        			statement = cnx.prepareStatement(secondQuery);
        			
        			statement.setInt(1, idCusto);
        			statement.setInt(2, idPro);
        			statement.setString(3, current_date);
        			statement.setInt(4, quantity_Product);
        			statement.setString(5, proName);
        			statement.setFloat(6, total_price);
        			
        			statement.execute();
        			
        			pro_name.setText("");
        			quantity.setText("");
        			
        		} catch (SQLException e) {
        			e.printStackTrace();
        		}
        		
        	}else {
            	//Insert the information for the Customer into the database appropriate
            	try {
        			statement = cnx.prepareStatement(beforeFirst);
        			statement.setString(1, nameCusto);
        			statement.execute();
        		} catch (SQLException e2) {
        			e2.printStackTrace();
        		}
        		
            	try {
            		statement = cnx.prepareStatement(verificationProductQUery);
        			result = statement.executeQuery();
        			while(result.next()) {
        				if(proName.equals(result.getString("pro_name"))) {
        					found = true;
        					idPro = result.getInt("id_pro");
        					//get the unit price of the product selected
        			    	try {
        			    		tempStatement = cnx.prepareStatement(firstQuery);
        						tempStatement.setString(1, proName);
        						tempResult = tempStatement.executeQuery();
        			
        						if(tempResult.next()) {
        							unit_Price = tempResult.getFloat("unit_price");
        							total_price = unit_Price*quantity_Product;
        						}
        				    	
        				    	tempStatement.close();	
        					} catch (SQLException e) {
        						e.printStackTrace();
        					  }		    	
        					}
        				}
        			
        			if (found == false){
        				Alert alert = new Alert(AlertType.INFORMATION,"This products is not available !",ButtonType.OK);
        				alert.showAndWait();
        			}
        		} catch (SQLException e1) {
        			System.out.println("Products unavailable !");
        		}
            	
        		//Insert into
            	try {
        			statement = cnx.prepareStatement(secondQuery);
        			
        			statement.setInt(1, idCusto);
        			statement.setInt(2, idPro);
        			statement.setString(3, current_date);
        			statement.setInt(4, quantity_Product);
        			statement.setString(5, proName);
        			statement.setFloat(6, total_price);
        			
        			statement.execute();
        			
        			pro_name.setText("");
        			quantity.setText("");
        			
        		} catch (SQLException e) {
        			e.printStackTrace();
        		}
            	
        	}
    		
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION,"Not enough product !",ButtonType.OK);
			alert.showAndWait();
    	}
    	
    	showRecord();
    	calculate_sumn();
    }

    @FXML
    void delete_record() {
    	Command liste = new Command();
    	liste = table_newRecord.getSelectionModel().getSelectedItem();
    	
    	int id = liste.getIdCustomer();
    	String proNames = liste.getProductName();
    	int quant = liste.getQuantity_commanded();
    	
    	String sql = "delete from Command where id_cust = ? and prod_name_com = ? and quantity_com = ?";
    	
    	try {
			statement = cnx.prepareStatement(sql);
			statement.setInt(1, id);
			statement.setString(2, proNames);
			statement.setInt(3, quant);
			statement.executeUpdate();
			
			Alert alert = new Alert(AlertType.ERROR,"Command selected deleted !",ButtonType.OK);
			alert.showAndWait();
			
			showRecord();
			calculate_sumn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    }

    @FXML
    void print_record() {
    	
    	
    }
    
    @FXML
    void calculate_sumn() {
    	try {
    		//Query to Calculate the sumn total
        	String calculateSumn = "select sum(total_price) as total from Command where id_cust = ?";
    		//calculate the sumn
	    	tempStatement = cnx.prepareStatement(calculateSumn);
	    	tempStatement.setInt(1, idCusto);
	    	tempResult = tempStatement.executeQuery();
	    	if(tempResult.next()) {
	    		lbl_total.setText(Float.toString((tempResult.getFloat("total"))));
	    	}
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}    	
    }
    
    public void showRecord() {
    	table_newRecord.getItems().clear();
    	String sql = "select * from Command where id_cust = ?";
    	try {
			statement = cnx.prepareStatement(sql);
			statement.setInt(1, idCusto);
			result = statement.executeQuery();
			while(result.next()) {
				data.add(new Command(result.getInt("id_cust"),result.getInt("id_pro"),result.getString("date_com"),result.getInt("quantity_com"),result.getString("prod_name_com"),result.getFloat("total_price")));
			}
			System.out.println("query Ok");
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	tab_id.setCellValueFactory(new PropertyValueFactory<Command, Integer>("idCustomer"));
    	tab_proName.setCellValueFactory(new PropertyValueFactory<Command, String>("productName"));
    	tab_quantity.setCellValueFactory(new PropertyValueFactory<Command, Integer>("quantity_commanded"));
    	tab_total.setCellValueFactory(new PropertyValueFactory<Command, Float>("totalPrice"));
    	tab_date.setCellValueFactory(new PropertyValueFactory<Command, String>("dateCommand"));
    	table_newRecord.setItems(data);
    }
    
    void showIdCustomer() {
    	//Query to set the id Customer
    	String setIdCustomer="select id_cust from Customer order by id_cust desc limit 1";
    	
    	try {
			statement  = cnx.prepareStatement(setIdCustomer);
			result = statement.executeQuery();
			while (result.next()) {
				idCusto = result.getInt("id_cust")+1;
				lbl_idCusto.setText(Integer.toString(idCusto));
			}
			statement.close();
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
    }
    
    public void chargeSuggestion() {
    	String query = "select pro_name from Products";
    	try {
			statement = cnx.prepareStatement(query);
			result = statement.executeQuery();
			while(result.next()) {
				suggestion.add(result.getString("pro_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    public void verifyTheProductQuantity() {
    	int quantity_Product_Commanded =  Integer.parseInt(quantity.getText());
    	int quantityTotalProduct = 0;
    	int restQuantity = 0;
    	String proName = pro_name.getText();
    	
    	//Query to get the total quantity of the product available
    	String getQuantity = "select quantity from Products where pro_name = ?";
    	
    	//Query to update the quantity of the Stock
    	String update = "update Products set quantity = ? where pro_name = ? ";
    	
    	try {
			statement = cnx.prepareStatement(getQuantity);
			statement.setString(1, proName);
			result = statement.executeQuery();
			while(result.next()) {
				quantityTotalProduct = result.getInt("quantity");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	if(quantityTotalProduct>quantity_Product_Commanded) {
    		restQuantity = quantityTotalProduct - quantity_Product_Commanded;
    		try {
				statement = cnx.prepareStatement(update);
				statement.setInt(1, restQuantity);
				statement.setString(2, proName);
				statement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
    		
    	}else {
    		Alert alert = new Alert(AlertType.ERROR,"Not enough product !",ButtonType.OK);
			alert.showAndWait();
    	}
    	
    }

	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	//This function will call by the new button NewCustomer
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		cnx = ConnexionMysql.connexionDb();
		showIdCustomer();
		showRecord();
		//chargeSuggestion();
		
		//TextFields.bindAutoCompletion(pro_name, suggestion);
		
		
	}

}
