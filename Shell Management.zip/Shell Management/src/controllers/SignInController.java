package controllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;

import application.ConnexionMysql;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class SignInController extends Application implements Initializable{

	@SuppressWarnings("exports")
	public Connection cnx;
	@SuppressWarnings("exports")
	public PreparedStatement statement;
	@SuppressWarnings("exports")
	public ResultSet result;
	
	@FXML
	private VBox vbox;	
	private Parent fxml;
	
	@FXML
	private TextField emailField;
	@FXML
    private PasswordField passwordField;
	
	public static String user;
	
	@FXML
	void openHome() {
		String username = emailField.getText();
		String password = passwordField.getText();
		String query = "select username,password,email from Login";
		boolean state=false;
		try {
			statement  = cnx.prepareStatement(query);
			result = statement.executeQuery();
			while (result.next()) {
				if(username.equals(result.getString("username"))&& password.equals(result.getString("password")) || username.equals(result.getString("email")) && password.equals(result.getString("password"))) {
					state = true;
					user = result.getString("username");
					vbox.getScene().getWindow().hide();
					Stage home = new Stage();
					try {
						fxml = FXMLLoader.load(getClass().getResource("/interfaces/Home.fxml"));
						Scene scene = new Scene(fxml);
						scene.setFill(Color.TRANSPARENT);
						home.setScene(scene);	
						home.initStyle(StageStyle.TRANSPARENT);
						home.show();
						
					}catch(IOException e) {
						e.printStackTrace();
					}
				}
			}
			if(state == false) {
				Alert alert = new Alert(AlertType.ERROR,"email(username) or password incorrect",ButtonType.OK);
				alert.showAndWait();
			}
		
		}catch (SQLException e1) {
		
			e1.printStackTrace();
		}
		
		
	}
	

	@SuppressWarnings("exports")
	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		cnx = ConnexionMysql.connexionDb();
		
		
	}	
	


	

}
