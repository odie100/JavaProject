package controllers;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDialogLayout;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import controllers.SignInController;

public class HomeController implements Initializable {
	 
		private Parent fxml;
	
		@FXML
	    private VBox vbox;
		
		@FXML
		private StackPane stack;
		
		@FXML
		private Label lblCurrentTime;
		
		@FXML
		private  Label logger;

	    @FXML
	    void new_sales(MouseEvent event) {
	    	try {
				fxml = FXMLLoader.load(getClass().getResource("/interfaces/NewSales.fxml"));
				vbox.getChildren().removeAll();
				vbox.getChildren().setAll(fxml);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }


	    @FXML
	    void sales_management(MouseEvent event) {
	    	try {
				fxml = FXMLLoader.load(getClass().getResource("/interfaces/SalesManagement.fxml"));
				vbox.getChildren().removeAll();
				vbox.getChildren().setAll(fxml);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }

	    @FXML
	    void stock(MouseEvent event) {
	    	try {
				fxml = FXMLLoader.load(getClass().getResource("/interfaces/Stock.fxml"));
				vbox.getChildren().removeAll();
				vbox.getChildren().setAll(fxml);
				
			} catch (IOException e) {
				e.printStackTrace();
			}
	    	
	    }
	    
	    @FXML
		private void quit(ActionEvent event) {
			System.exit(0);
		}
	    
	    @FXML
	    void LogOut() {
			vbox.getScene().getWindow().hide();
			Stage home = new Stage();
	
			
			try {
				fxml = FXMLLoader.load(getClass().getResource("/interfaces/Login.fxml"));
				Scene scene = new Scene(fxml);
				scene.setFill(Color.TRANSPARENT);
				scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());
				home.setScene(scene);
				home.initStyle(StageStyle.TRANSPARENT);
				home.show();
				
			}catch(IOException e) {
				e.printStackTrace();
			}
		}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			fxml = FXMLLoader.load(getClass().getResource("/interfaces/Stock.fxml"));
			vbox.getChildren().removeAll();
			vbox.getChildren().setAll(fxml);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		currentTime();
		logger.setText(SignInController.user);
	}
	
	@FXML
	private void showAbout() {
		
	}
	
	//Show the current time
	public void currentTime() {
		Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
	        lblCurrentTime.setText(LocalDateTime.now().format(formatter));
	    }), new KeyFrame(Duration.seconds(1)));
	    clock.setCycleCount(Animation.INDEFINITE);
	    clock.play();
			
	}
	

}
