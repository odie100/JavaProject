package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import application.ConnexionMysql;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Stock;


public class StockController extends Application implements Initializable{

	@SuppressWarnings("exports")
	public Connection cnx;
	@SuppressWarnings("exports")
	public PreparedStatement statement;
	@SuppressWarnings("exports")
	public ResultSet result;

	@FXML
    private TableView<Stock> table_stock;

    @FXML
    private TableColumn<Stock, Integer> tab_id_products;

    @FXML
    private TableColumn<Stock, String> tab_product_name;

    @FXML
    private TableColumn<Stock, String> tab_description;

    @FXML
    private TableColumn<Stock, Float> tab_unit_price;

    @FXML
    private TableColumn<Stock, Integer> tab_quantity;

    @FXML
    private Button btn_add;

    @FXML
    private Button btn_delete;

    @FXML
    private TextField fieldSearch;

    @FXML
    private Button btn_modify;

    @FXML
    private TextField nameProductField;

    @FXML
    private TextField UnitPriceField;

    @FXML
    private TextField QuantityField;

    @FXML
    private TextArea DescriptionFIeld;
    
    @FXML
    private ComboBox combChoice;
    
    public ObservableList<Stock> data = FXCollections.observableArrayList();
    public ObservableList<String> menu = FXCollections.observableArrayList("name","unit price");
    String menuSelected;
    

    @FXML
    void add_product() {
    	String proName =  nameProductField.getText();
    	String proUnitPrice =  UnitPriceField.getText();
    	String proQuantity =  QuantityField.getText();
    	String proDescription =  DescriptionFIeld.getText();
      	    
    	String sql = "insert into Products(pro_name,description,unit_price,quantity) values(?,?,?,?)";
    	
    	if(!proName.equals("") && !proUnitPrice.equals("") && !proQuantity.equals("")) {
    		try {
				statement = cnx.prepareStatement(sql);
				
				statement.setString(1, proName);
				statement.setString(2, proDescription);
				statement.setString(3, proUnitPrice);
				statement.setString(4, proQuantity);
				statement.execute();
				
				nameProductField.setText("");
				UnitPriceField.setText("");
				QuantityField.setText("");
				DescriptionFIeld.setText("");
				
				Alert alert = new Alert(AlertType.CONFIRMATION,"Product added successful", ButtonType.OK);
				alert.showAndWait();
				showStock();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}else {
    		Alert alert = new Alert(AlertType.WARNING,"Please fill the field !", ButtonType.OK);
			alert.showAndWait();
    	}
    	
    }

    @FXML
    void delete_stock() {
    	//If the Products was bouthg by some Customer so we can't delete this token because of the foreign key is already in use
    	Stock liste = table_stock.getSelectionModel().getSelectedItem();
    	liste = table_stock.getSelectionModel().getSelectedItem();
    	int id = liste.getIdProducts();
    	System.out.println(id);
    	
    	String sql = "delete from Products where id_pro = ?";
    	try {
			statement = cnx.prepareStatement(sql);
			statement.setInt(1, id);
			statement.executeUpdate();
			
			Alert alert = new Alert(AlertType.CONFIRMATION,"Product deleted successful", ButtonType.OK);
			alert.showAndWait();
			
			nameProductField.setText("");
			UnitPriceField.setText("");
			QuantityField.setText("");
			DescriptionFIeld.setText("");
			
			showStock();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    @FXML
    void modify_stock() {    	
    	Stock liste = table_stock.getSelectionModel().getSelectedItem();
    	liste = table_stock.getSelectionModel().getSelectedItem();
    	
    	int id = liste.getIdProducts();
   	
    	String newName = nameProductField.getText();
    	Float newUnitPrice = Float.parseFloat(UnitPriceField.getText());
    	int newQuantity = Integer.parseInt(QuantityField.getText());
    	String newDescription = DescriptionFIeld.getText();
    	   	
    	String sql = "update Products set pro_name=?, description=?,unit_price=?, quantity=? where id_pro = "+id+"";
    	
    	if(!nameProductField.getText().equals("") && ! (UnitPriceField.getText()).equals("") && ! QuantityField.getText().equals("")) {
    		try {
				statement = cnx.prepareStatement(sql);
				statement.setString(1, newName);
				statement.setString(2, newDescription);
				statement.setFloat(3, newUnitPrice);
				statement.setInt(4, newQuantity);
				
				statement.executeUpdate();
				
				nameProductField.setText("");
				UnitPriceField.setText("");
				QuantityField.setText("");
				DescriptionFIeld.setText("");
				
				Alert alert = new Alert(AlertType.CONFIRMATION,"Product modified successful", ButtonType.OK);
				alert.showAndWait();
				showStock();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
    	}else {
    		Alert alert = new Alert(AlertType.WARNING,"Please fill the field !", ButtonType.OK);
			alert.showAndWait();
    	}	
    	
    }

    @FXML
    void search_stock() {
    	String sql = "select id_pro, pro_name, description, unit_price, quantity from Products where pro_name like '%"+fieldSearch.getText()+"%'";
    	
    	if (menuSelected.equals("name")) {
    		 sql = "select id_pro, pro_name, description, unit_price, quantity from Products where pro_name like '%"+fieldSearch.getText()+"%'";
    	}else {
    		 sql = "select id_pro, pro_name, description, unit_price, quantity from Products where unit_price like '%"+fieldSearch.getText()+"%'";
    	}
    	
    	boolean vide = true;
   
    	table_stock.getItems().clear();
 
    	try {
			statement = cnx.prepareStatement(sql);
			result = statement.executeQuery();
			while(result.next()) {
				vide = false;
				data.add(new Stock(result.getInt("id_pro"),result.getString("pro_name"),result.getString("description"),result.getFloat("unit_price"),result.getInt("quantity")));
			}
			if (vide) {
				Alert alert = new Alert(AlertType.WARNING,"Products unavailable !", ButtonType.OK);
				alert.showAndWait();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	tab_id_products.setCellValueFactory(new PropertyValueFactory<Stock, Integer>("idProducts"));
    	tab_product_name.setCellValueFactory(new PropertyValueFactory<Stock, String>("productsName"));
    	tab_description.setCellValueFactory(new PropertyValueFactory<Stock, String>("description"));
    	tab_unit_price.setCellValueFactory(new PropertyValueFactory<Stock, Float>("unitPrice"));
    	tab_quantity.setCellValueFactory(new PropertyValueFactory<Stock, Integer>("quantity"));
    	table_stock.setItems(data);
    	
    }
    
    public void showStock() {
    	table_stock.getItems().clear();
    	String sql = "select * from Products";
    	try {
			statement = cnx.prepareStatement(sql);
			result = statement.executeQuery();
			while(result.next()) {
				data.add(new Stock(result.getInt("id_pro"),result.getString("pro_name"),result.getString("description"),result.getFloat("unit_price"),result.getInt("quantity")));
			}
			System.out.println("query Ok");
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	
    	tab_id_products.setCellValueFactory(new PropertyValueFactory<Stock, Integer>("idProducts"));
    	tab_product_name.setCellValueFactory(new PropertyValueFactory<Stock, String>("productsName"));
    	tab_description.setCellValueFactory(new PropertyValueFactory<Stock, String>("description"));
    	tab_unit_price.setCellValueFactory(new PropertyValueFactory<Stock, Float>("unitPrice"));
    	tab_quantity.setCellValueFactory(new PropertyValueFactory<Stock, Integer>("quantity"));
    	table_stock.setItems(data);
    }
    
    @FXML
    
    public void showDetail() {
    	Stock liste = table_stock.getSelectionModel().getSelectedItem();
    	liste = table_stock.getSelectionModel().getSelectedItem();
    	
    	int id = liste.getIdProducts();
      	String proName =  liste.getProductsName();
    	float proUnitPrice =  liste.getUnitPrice();
    	int proQuantity =  liste.getQuantity();
    	String proDescription = liste.getDescription();
    	
    	nameProductField.setText(proName);
    	UnitPriceField.setText(Float.toString(proUnitPrice));
    	QuantityField.setText(Integer.toString(proQuantity));
    	DescriptionFIeld.setText(proDescription);
    }
	
    @FXML
    void checkSelectedMenu() {
    	 menuSelected = (String) combChoice.getSelectionModel().getSelectedItem();
    }
	
	
	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		cnx = ConnexionMysql.connexionDb();
		showStock();
		combChoice.setItems(menu);
	}


}
