package controllers;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JComboBox;

import org.controlsfx.control.textfield.TextFields;

import com.jfoenix.controls.JFXComboBox;

import application.ConnexionMysql;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import models.Management;

public class SellerHomeController extends Application  implements Initializable{


	@SuppressWarnings("exports")
	public Connection cnx;
	@SuppressWarnings("exports")
	public PreparedStatement statement;
	@SuppressWarnings("exports")
	public ResultSet result;
	
	
	   @FXML
	    private TableView<Management> tab_management;

	    @FXML
	    private TableColumn<Management, Integer> tab_idCust;

	    @FXML
	    private TableColumn<Management, String> tab_custName;

	    @FXML
	    private TableColumn<Management, String> tab_productName;

	    @FXML
	    private TableColumn<Management, Integer> tab_quantity;
	    
	    @FXML
	    private TableColumn<Management, Float> tab_total_price;


	    @FXML
	    private TableColumn<Management, String> tab_date;

	    @FXML
	    private TextField search_field = TextFields.createClearableTextField();
	    
	     @FXML
	    private JFXComboBox choice;
	         
	     @FXML
	    private Label lblTotalMoney;
	     
	     @FXML
	    private Label lblTotalBy;

	     @FXML
	    private Label filterTotal;
    
	    String menuSelectedItem;

	    public ObservableList<Management> data = FXCollections.observableArrayList();
	    public ObservableList<String> menu = FXCollections.observableArrayList("Customer's name","Products's name","date");
	    
	    @FXML
	    void Search() {
	    	boolean vide = true;
	    	String sql = "select Customer.id_cust, Customer.cust_name, Command.prod_name_com, Command.quantity_com, Command.total_price, Command.date_com from Customer inner join Command on Customer.id_cust = Command.id_cust where Customer.cust_name like '"+search_field.getText()+"%'";
	    	String calcTotalByQuery = "select sum(Command.total_price) as total from Command inner join Customer on Command.id_cust = Customer.id_cust where Customer.cust_name like '"+search_field.getText()+"%'";
	  
	    	tab_management.getItems().clear();
	    	
	    	switch(menuSelectedItem){
	    		
	    		case "Customer's name":
	    			sql = "select Customer.id_cust, Customer.cust_name, Command.prod_name_com, Command.quantity_com, Command.total_price, Command.date_com from Customer inner join Command on Customer.id_cust = Command.id_cust where Customer.cust_name like '"+search_field.getText()+"%'";
	    			calcTotalByQuery = "select sum(Command.total_price) as total from Command inner join Customer on Command.id_cust = Customer.id_cust where Customer.cust_name like '"+search_field.getText()+"%'";
	    			try {
	    				statement = cnx.prepareStatement(calcTotalByQuery);
	    				result = statement.executeQuery();
	    				if(result.next()) {
	    					lblTotalBy.setText(String.valueOf(result.getFloat("total")));
	    				}
	    			} catch (SQLException e) {
	    				e.printStackTrace();
	    			}
	    			break;
	    		case "Products's name":
	    			sql = "select Customer.id_cust, Customer.cust_name, Command.prod_name_com, Command.quantity_com, Command.total_price, Command.date_com from Customer inner join Command on Customer.id_cust = Command.id_cust where Command.prod_name_com like '"+search_field.getText()+"%'";
	    			calcTotalByQuery = "select sum(Command.total_price) as total from Command inner join Customer on Command.id_cust = Customer.id_cust where Command.prod_name_com like '"+search_field.getText()+"%'";
	    			try {
	    				statement = cnx.prepareStatement(calcTotalByQuery);
	    				result = statement.executeQuery();
	    				if(result.next()) {
	    					lblTotalBy.setText(String.valueOf(result.getFloat("total")));
	    				}
	    			} catch (SQLException e) {
	    				e.printStackTrace();
	    			}
	    			break;
	    		case "date":
	    			sql = "select Customer.id_cust, Customer.cust_name, Command.prod_name_com, Command.quantity_com, Command.total_price, Command.date_com from Customer inner join Command on Customer.id_cust = Command.id_cust where Command.date_com like '"+search_field.getText()+"%'";
	    			calcTotalByQuery = "select sum(Command.total_price) as total from Command inner join Customer on Command.id_cust = Customer.id_cust where Command.date_com like '"+search_field.getText()+"%'";
	    			try {
	    				statement = cnx.prepareStatement(calcTotalByQuery);
	    				result = statement.executeQuery();
	    				if(result.next()) {
	    					lblTotalBy.setText(String.valueOf(result.getFloat("total")));
	    				}
	    			} catch (SQLException e) {
	    				e.printStackTrace();
	    			}
	    			break;
	    		default:
	    			Alert alert = new Alert(AlertType.WARNING,"Please select your choice from the list available !", ButtonType.OK);
	    			alert.showAndWait();
	    	}
	 
	    	try {
				statement = cnx.prepareStatement(sql);
				result = statement.executeQuery();
				while(result.next()) {
					vide = false;
					data.add(new Management(result.getInt("Customer.id_cust"),result.getString("Customer.cust_name"),result.getString("Command.prod_name_com"),result.getInt("Command.quantity_com"),result.getFloat("Command.total_price"), result.getString("Command.date_com")));
				}
				if (search_field.getText().equals("")) {
    				lblTotalBy.setText("");
    			}
				if (vide) {
					Alert alert = new Alert(AlertType.WARNING,"No sale(s) found !", ButtonType.OK);
					alert.showAndWait();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}	    	
	    	
	    	tab_idCust.setCellValueFactory(new PropertyValueFactory<Management, Integer>("idCustomer"));
	    	tab_custName.setCellValueFactory(new PropertyValueFactory<Management, String>("customerName"));
	    	tab_productName.setCellValueFactory(new PropertyValueFactory<Management, String>("productsName"));
	    	tab_quantity.setCellValueFactory(new PropertyValueFactory<Management, Integer>("quantity"));
	    	tab_total_price.setCellValueFactory(new PropertyValueFactory<Management, Float>("totalPrice"));
	    	tab_date.setCellValueFactory(new PropertyValueFactory<Management, String>("date"));
	    	tab_management.setItems(data);
	    	
	    }
	    
	    void showValues() {
	    	tab_management.getItems().clear();
	    	String query = "select Command.id_cust, Customer.cust_name, Command.prod_name_com, Command.quantity_com, Command.total_price, Command.date_com from Command inner join Customer on Customer.id_cust = Command.id_cust";
	    	try {
				statement = cnx.prepareStatement(query);
				result = statement.executeQuery();
				
				while(result.next()) {
					data.add(new Management(result.getInt("id_cust"),result.getString("Customer.cust_name"), result.getString("Command.prod_name_com"), result.getInt("Command.quantity_com"),result.getFloat("Command.total_price"), result.getString("Command.date_com") ));
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
	    	
	    	tab_idCust.setCellValueFactory(new PropertyValueFactory<Management, Integer>("idCustomer"));
	    	tab_custName.setCellValueFactory(new PropertyValueFactory<Management, String>("customerName"));
	    	tab_productName.setCellValueFactory(new PropertyValueFactory<Management, String>("productsName"));
	    	tab_quantity.setCellValueFactory(new PropertyValueFactory<Management, Integer>("quantity"));
	    	tab_total_price.setCellValueFactory(new PropertyValueFactory<Management, Float>("totalPrice"));
	    	tab_date.setCellValueFactory(new PropertyValueFactory<Management, String>("date"));
	    	
	    	tab_management.setItems(data);
	    	
	    	
	    }
	
	    @FXML
	    void checkSelectedItem() {
	    	menuSelectedItem = (String) choice.getSelectionModel().getSelectedItem();
	    	filterTotal.setText(menuSelectedItem);
	    	lblTotalBy.setText("");
	    	  
	    	
	    }
	
	
	@Override
	public void start(Stage arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	public void showTotalPrice() {
		float money = 0;
		String query = "select sum(total_price) as money from Command";
		try {
			statement = cnx.prepareStatement(query);
			result = statement.executeQuery();
			while(result.next()) {
				money = result.getFloat("money");
				lblTotalMoney.setText(String.valueOf(money));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		cnx = ConnexionMysql.connexionDb();
		showValues();
		choice.setItems(menu);
		showTotalPrice();
	}

}
